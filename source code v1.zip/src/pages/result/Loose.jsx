import React from 'react'

const Loose = () => {
  return (
    <div className=' min-h-screen  flex items-center justify-center w-full'>
        <h1 className=' text-center text-white text-2xl'>Sorry You Loose the game</h1>
    </div>
  )
}

export default Loose